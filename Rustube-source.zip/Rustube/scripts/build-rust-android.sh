#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT/rust"

if ! command -v cargo-ndk >/dev/null 2>&1; then
  echo "cargo-ndk is required. Install it with: cargo install cargo-ndk" >&2
  exit 1
fi
if [[ -z "${ANDROID_NDK_HOME:-}${ANDROID_NDK_ROOT:-}" ]]; then
  SDK_ROOT="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
  if [[ -n "$SDK_ROOT" && -d "$SDK_ROOT/ndk" ]]; then
    NDK_DIR="$(find "$SDK_ROOT/ndk" -mindepth 1 -maxdepth 1 -type d | sort -V | tail -n 1)"
    if [[ -n "$NDK_DIR" ]]; then export ANDROID_NDK_HOME="$NDK_DIR"; fi
  fi
fi
if [[ -z "${ANDROID_NDK_HOME:-}${ANDROID_NDK_ROOT:-}" ]]; then
  echo "Android NDK not found. Set ANDROID_NDK_HOME or install it through sdkmanager." >&2
  exit 1
fi

cargo ndk -t arm64-v8a -t armeabi-v7a -t x86_64 -o "$ROOT/app/src/main/jniLibs" build --release
