package com.tensei.ytxtube

import org.json.JSONArray

/**
 * Optional JNI acceleration for large WebVTT tracks.
 * The app remains fully functional when the native library is absent (local debug builds,
 * unsupported ABIs, or devices where the library could not be loaded).
 */
internal object RustEngine {
    private const val NATIVE_MIN_CHARS = 16_384

    private val available: Boolean by lazy(LazyThreadSafetyMode.PUBLICATION) {
        runCatching {
            System.loadLibrary("rustube_core")
            true
        }.getOrDefault(false)
    }

    private external fun nativeParseVtt(raw: String): String

    fun parseVtt(raw: String): List<ParsedCue>? {
        if (raw.length < NATIVE_MIN_CHARS || !available) return null
        return runCatching {
            val result = JSONArray(nativeParseVtt(raw))
            buildList(result.length()) {
                for (index in 0 until result.length()) {
                    val cue = result.getJSONObject(index)
                    add(ParsedCue(cue.getLong("s"), cue.getLong("e"), cue.getString("t")))
                }
            }
        }.getOrNull()
    }
}
