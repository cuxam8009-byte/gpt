package com.tensei.ytxtube

import android.app.Activity
import android.content.Context
import android.content.SharedPreferences
import android.graphics.drawable.ColorDrawable
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.LocalContentColor
import androidx.compose.material3.LocalRippleConfiguration
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.DeviceFontFamilyName
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat

val ExpressiveShapes = Shapes(
    extraSmall = RoundedCornerShape(8.dp),
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(30.dp),
)

private val RustubeRoundedFont = FontFamily(
    Font(DeviceFontFamilyName("sans-serif"), weight = FontWeight.Bold),
    Font(DeviceFontFamilyName("sans-serif"), weight = FontWeight.ExtraBold),
)

val RoundedHeavy: FontFamily
    get() = if (ThemeSettings.useSystemFont) FontFamily.Default else RustubeRoundedFont

data class ThemeChoice(val name: String, val hex: String, val isNew: Boolean = false)

const val SEED_RUSTUBE = "#111111"
val RUSTUBE_THEMES = listOf(ThemeChoice("Monochrome", SEED_RUSTUBE))

object ThemeSettings {
    private var prefs: SharedPreferences? = null

    val wallpaperAvailable = false

    var seed by mutableStateOf<String?>(SEED_RUSTUBE)
        private set

    var mode by mutableStateOf("system")
        private set

    var useSystemFont by mutableStateOf(true)
        private set

    fun init(context: Context) {
        val p = context.getSharedPreferences("appearance", Context.MODE_PRIVATE).also { prefs = it }
        seed = SEED_RUSTUBE
        mode = p.getString("mode", "system") ?: "system"
        useSystemFont = p.getBoolean("use_system_font", true)
    }

    @Suppress("UNUSED_PARAMETER")
    fun choose(seedHex: String?) {
        seed = SEED_RUSTUBE
        prefs?.edit()?.putString("seed", SEED_RUSTUBE)?.apply()
    }

    fun chooseMode(value: String) {
        mode = value
        prefs?.edit()?.putString("mode", value)?.apply()
    }

    fun updateUseSystemFont(enabled: Boolean) {
        useSystemFont = enabled
        prefs?.edit()?.putBoolean("use_system_font", enabled)?.apply()
    }
}

private fun rustubeScheme(dark: Boolean): ColorScheme = if (!dark) {
    lightColorScheme(
        primary = Color(0xFF111111),
        onPrimary = Color.White,
        primaryContainer = Color(0xFFE8E8ED),
        onPrimaryContainer = Color(0xFF111111),
        secondary = Color(0xFF6E6E73),
        onSecondary = Color.White,
        secondaryContainer = Color(0xFFE5E5EA),
        onSecondaryContainer = Color(0xFF1C1C1E),
        tertiary = Color(0xFF303034),
        tertiaryContainer = Color(0xFFF0F0F4),
        onTertiaryContainer = Color(0xFF111111),
        background = Color(0xFFF5F5F7),
        onBackground = Color(0xFF111111),
        surface = Color(0xFFF5F5F7),
        onSurface = Color(0xFF111111),
        surfaceVariant = Color(0xFFE5E5EA),
        onSurfaceVariant = Color(0xFF6E6E73),
        surfaceContainerLowest = Color.White,
        surfaceContainerLow = Color.White,
        surfaceContainer = Color(0xFFF0F0F3),
        surfaceContainerHigh = Color(0xFFE8E8ED),
        surfaceContainerHighest = Color(0xFFE1E1E6),
        outline = Color(0xFF8E8E93),
        outlineVariant = Color(0xFFE5E5EA),
        error = Color(0xFFB3261E),
        onError = Color.White,
    )
} else {
    darkColorScheme(
        primary = Color(0xFFF5F5F7),
        onPrimary = Color(0xFF111111),
        primaryContainer = Color(0xFF2C2C2E),
        onPrimaryContainer = Color(0xFFF5F5F7),
        secondary = Color(0xFF98989D),
        onSecondary = Color(0xFF111111),
        secondaryContainer = Color(0xFF2C2C2E),
        onSecondaryContainer = Color(0xFFF5F5F7),
        tertiary = Color(0xFFD1D1D6),
        tertiaryContainer = Color(0xFF1C1C1E),
        onTertiaryContainer = Color(0xFFF5F5F7),
        background = Color.Black,
        onBackground = Color(0xFFF5F5F7),
        surface = Color.Black,
        onSurface = Color(0xFFF5F5F7),
        surfaceVariant = Color(0xFF1C1C1E),
        onSurfaceVariant = Color(0xFF98989D),
        surfaceContainerLowest = Color.Black,
        surfaceContainerLow = Color(0xFF101012),
        surfaceContainer = Color(0xFF1C1C1E),
        surfaceContainerHigh = Color(0xFF2C2C2E),
        surfaceContainerHighest = Color(0xFF3A3A3C),
        outline = Color(0xFF636366),
        outlineVariant = Color(0xFF2C2C2E),
        error = Color(0xFFFF453A),
        onError = Color(0xFF1C1C1E),
    )
}

@Suppress("UNUSED_PARAMETER")
fun schemeFor(context: Context, seedHex: String?, dark: Boolean): ColorScheme = rustubeScheme(dark)

@Composable
fun isDarkTheme(): Boolean = when (ThemeSettings.mode) {
    "dark", "amoled" -> true
    "light" -> false
    else -> isSystemInDarkTheme()
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RustubeTheme(content: @Composable () -> Unit) {
    val dark = isDarkTheme()
    val isAmoled = ThemeSettings.mode == "amoled"
    val scheme = if (isAmoled) {
        rustubeScheme(dark = true).copy(
            background = Color.Black,
            surface = Color.Black,
            surfaceVariant = Color(0xFF141414),
            surfaceContainerLowest = Color.Black,
            surfaceContainerLow = Color(0xFF050505),
            surfaceContainer = Color(0xFF0C0C0C),
            surfaceContainerHigh = Color(0xFF141414),
            surfaceContainerHighest = Color(0xFF1E1E1E),
            onBackground = Color(0xFFF5F5F5),
            onSurface = Color(0xFFF5F5F5),
            outlineVariant = Color(0xFF1F1F1F),
        )
    } else {
        rustubeScheme(dark)
    }

    SystemBars(dark, scheme.surface)
    MaterialTheme(colorScheme = scheme, shapes = ExpressiveShapes, typography = Typography()) {
        CompositionLocalProvider(
            LocalRippleConfiguration provides null,
            LocalContentColor provides scheme.onSurface,
            content = content,
        )
    }
}

@Composable
private fun SystemBars(dark: Boolean, windowBg: Color) {
    val view = LocalView.current
    if (view.isInEditMode) return
    val activity = view.context as? ComponentActivity

    SideEffect {
        val window = activity?.window ?: (view.context as? Activity)?.window ?: return@SideEffect
        val controller = WindowCompat.getInsetsController(window, view)
        controller.isAppearanceLightStatusBars = !dark
        controller.isAppearanceLightNavigationBars = !dark

        if (activity != null) {
            val barStyle = if (dark) {
                SystemBarStyle.dark(android.graphics.Color.TRANSPARENT)
            } else {
                SystemBarStyle.light(android.graphics.Color.TRANSPARENT, android.graphics.Color.TRANSPARENT)
            }
            runCatching {
                activity.enableEdgeToEdge(statusBarStyle = barStyle, navigationBarStyle = barStyle)
                controller.isAppearanceLightStatusBars = !dark
                controller.isAppearanceLightNavigationBars = !dark
            }
        }
    }

    DisposableEffect(windowBg) {
        (view.context as? Activity)?.window?.setBackgroundDrawable(ColorDrawable(windowBg.toArgb()))
        onDispose { }
    }
}
