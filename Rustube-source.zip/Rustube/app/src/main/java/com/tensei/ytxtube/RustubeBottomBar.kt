package com.tensei.ytxtube

import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** A quiet, monochrome tab bar. No blur, animated glass, or oversized selection pill. */
@Composable
fun RustubeBottomBar(
    selectedTab: Tab,
    onSelect: (Tab) -> Unit,
    darkSurface: Boolean,
    modifier: Modifier = Modifier,
) {
    val scheme = MaterialTheme.colorScheme
    val background = if (darkSurface) Color.Black else scheme.surface
    val primary = if (darkSurface) Color.White else scheme.onSurface
    val secondary = if (darkSurface) Color(0xFF8E8E93) else scheme.onSurfaceVariant

    Surface(
        modifier = modifier.height(66.dp),
        color = background,
        contentColor = primary,
        shape = RoundedCornerShape(20.dp),
        shadowElevation = 8.dp,
        tonalElevation = 0.dp,
    ) {
        Column(Modifier.fillMaxWidth()) {
            HorizontalDivider(color = if (darkSurface) Color(0xFF2C2C2E) else scheme.outlineVariant)
            Row(
                modifier = Modifier.fillMaxWidth().weight(1f).padding(horizontal = 4.dp, vertical = 3.dp),
                horizontalArrangement = Arrangement.spacedBy(2.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Tab.entries.forEach { tab ->
                    val selected = tab == selectedTab
                    val interaction = remember(tab) { MutableInteractionSource() }
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxHeight()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable(interactionSource = interaction, indication = null) { onSelect(tab) }
                            .padding(vertical = 4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center,
                    ) {
                        Icon(
                            imageVector = if (selected) tab.selectedIcon else tab.icon,
                            contentDescription = tab.label,
                            tint = if (selected) primary else secondary,
                            modifier = Modifier.size(21.dp),
                        )
                        Text(
                            text = tab.label,
                            color = if (selected) primary else secondary,
                            fontSize = 10.sp,
                            lineHeight = 12.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Medium,
                            maxLines = 1,
                        )
                    }
                }
            }
        }
    }
}
