# Rustube native core

This crate contains the optional Rust JNI accelerator used for large WebVTT subtitle tracks.
It does **not** replace NewPipe Extractor, OkHttp, or Media3/ExoPlayer. Those components remain
responsible for YouTube extraction, network I/O, and video/audio decoding.

## Build Android libraries

Install the Android NDK, Rust stable, the Android Rust targets, and `cargo-ndk`, then run:

```bash
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
cargo install cargo-ndk
./scripts/build-rust-android.sh
```

The script writes ABI libraries to `app/src/main/jniLibs/`. Gradle packages them into the APK.
Kotlin uses the JNI parser only for VTT files of at least 4 KiB; otherwise it uses the existing
Kotlin parser. If the library is missing or JNI parsing fails, Kotlin fallback remains active.

## Performance policy

No speedup percentage is claimed yet. Benchmark on representative low-, mid-, and high-end
Android hardware before lowering the 4 KiB dispatch threshold or porting another unit.
