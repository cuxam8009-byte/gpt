use jni::objects::{JObject, JString};
use jni::sys::jstring;
use jni::JNIEnv;
use std::ptr;

#[derive(Debug, PartialEq, Eq)]
struct Cue {
    start_ms: i64,
    end_ms: i64,
    text: String,
}

fn parse_timestamp(value: &str) -> Option<i64> {
    let value = value.trim().trim_end_matches('s').replace(',', ".");
    let parts: Vec<&str> = value.split(':').collect();
    let millis = match parts.as_slice() {
        [seconds] => seconds.parse::<f64>().ok()? * 1_000.0,
        [minutes, seconds] => {
            minutes.parse::<i64>().ok()? as f64 * 60_000.0
                + seconds.parse::<f64>().ok()? * 1_000.0
        }
        [hours, minutes, seconds] => {
            hours.parse::<i64>().ok()? as f64 * 3_600_000.0
                + minutes.parse::<i64>().ok()? as f64 * 60_000.0
                + seconds.parse::<f64>().ok()? * 1_000.0
        }
        _ => return None,
    };
    if !millis.is_finite() || millis < 0.0 || millis > i64::MAX as f64 {
        return None;
    }
    Some(millis as i64)
}

fn timing(line: &str) -> Option<(i64, i64)> {
    let (left, right) = line.split_once("-->")?;
    let start_token = left.split_whitespace().last()?;
    let end_token = right.split_whitespace().next()?;
    let start = parse_timestamp(start_token)?;
    let end = parse_timestamp(end_token)?;
    Some((start, end))
}

fn clean_text(source: &str) -> String {
    let mut no_tags = String::with_capacity(source.len());
    let mut inside_tag = false;
    for ch in source.chars() {
        match ch {
            '<' => inside_tag = true,
            '>' if inside_tag => inside_tag = false,
            _ if !inside_tag => no_tags.push(ch),
            _ => {}
        }
    }

    // Keep the same entity replacement order as the Kotlin implementation.
    let decoded = no_tags
        .replace("&amp;", "&")
        .replace("&#39;", "'")
        .replace("&apos;", "'")
        .replace("&quot;", "\"")
        .replace("&lt;", "<")
        .replace("&gt;", ">")
        .replace("&#10;", "\n");

    let mut compact = String::with_capacity(decoded.len());
    let mut previous_newline = false;
    for ch in decoded.chars() {
        if ch == '\n' {
            if !previous_newline {
                compact.push(ch);
            }
            previous_newline = true;
        } else {
            compact.push(ch);
            previous_newline = false;
        }
    }
    compact.trim().to_string()
}

fn parse_vtt(raw: &str) -> Vec<Cue> {
    let normalized = raw.replace("\r\n", "\n").replace('\r', "\n");
    let mut cues = Vec::new();
    for block in normalized.split("\n\n") {
        let lines: Vec<&str> = block.lines().map(str::trim).filter(|line| !line.is_empty()).collect();
        let mut found = None;
        for (index, line) in lines.iter().enumerate() {
            if let Some((start, end)) = timing(line) {
                found = Some((index, start, end));
                break;
            }
        }
        let Some((time_index, start_ms, end_ms)) = found else { continue };
        let text = clean_text(&lines[time_index + 1..].join("\n"));
        if !text.is_empty() {
            cues.push(Cue { start_ms, end_ms, text });
        }
    }
    cues
}

fn json_escape(input: &str, out: &mut String) {
    for ch in input.chars() {
        match ch {
            '"' => out.push_str("\\\""),
            '\\' => out.push_str("\\\\"),
            '\n' => out.push_str("\\n"),
            '\r' => out.push_str("\\r"),
            '\t' => out.push_str("\\t"),
            c if c <= '\u{001f}' => {
                use std::fmt::Write;
                let _ = write!(out, "\\u{:04x}", c as u32);
            }
            c => out.push(c),
        }
    }
}

fn cues_to_json(cues: &[Cue]) -> String {
    let mut out = String::with_capacity(cues.iter().map(|c| c.text.len() + 48).sum::<usize>() + 2);
    out.push('[');
    for (index, cue) in cues.iter().enumerate() {
        if index > 0 { out.push(','); }
        out.push_str("{\"s\":");
        out.push_str(&cue.start_ms.to_string());
        out.push_str(",\"e\":");
        out.push_str(&cue.end_ms.to_string());
        out.push_str(",\"t\":\"");
        json_escape(&cue.text, &mut out);
        out.push_str("\"}");
    }
    out.push(']');
    out
}

#[no_mangle]
pub extern "system" fn Java_com_tensei_ytxtube_RustEngine_nativeParseVtt(
    mut env: JNIEnv,
    _this: JObject,
    input: JString,
) -> jstring {
    let raw: String = match env.get_string(&input) {
        Ok(value) => value.into(),
        Err(_) => return ptr::null_mut(),
    };
    let json = cues_to_json(&parse_vtt(&raw));
    match env.new_string(json) {
        Ok(value) => value.into_raw(),
        Err(_) => ptr::null_mut(),
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn parses_cues_with_ids_and_settings() {
        let input = "WEBVTT\n\nintro\n00:00:01.000 --> 00:00:02.500 align:start\nHello <b>world</b> &amp; all\n\n00:01.000 --> 00:02.000\nSecond cue";
        let cues = parse_vtt(input);
        assert_eq!(cues.len(), 2);
        assert_eq!(cues[0], Cue { start_ms: 1_000, end_ms: 2_500, text: "Hello world & all".into() });
        assert_eq!(cues[1].start_ms, 1_000);
    }

    #[test]
    fn handles_comma_milliseconds_and_crlf() {
        let input = "WEBVTT\r\n\r\n00:00:02,125 --> 00:00:04,500\r\nLine one\r\nLine two";
        let cues = parse_vtt(input);
        assert_eq!(cues.len(), 1);
        assert_eq!(cues[0].start_ms, 2_125);
        assert_eq!(cues[0].end_ms, 4_500);
        assert_eq!(cues[0].text, "Line one\nLine two");
    }

    #[test]
    fn escapes_json_control_characters() {
        let mut result = String::new();
        json_escape("a\nb\\c\"", &mut result);
        assert_eq!(result, "a\\nb\\\\c\\\"");
    }
}
