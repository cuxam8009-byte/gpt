# Rustube

Rustube is an Android YouTube client fork based on the GPL-3.0 YTXTube source tree. The fork keeps
the existing YouTube extraction and Media3 playback pipeline while introducing a monochrome,
Apple-inspired interface and an optional Rust JNI path for large WebVTT subtitle parsing.

## Design direction

- Monochrome light/dark appearance; no accent-color carousel.
- Native sans-serif typography, inset video cards, simple five-item bottom navigation.
- Less decorative motion and no glass effect in the primary navigation.

## Playback architecture

- **NewPipe Extractor** retrieves YouTube metadata and stream URLs.
- **Media3 / ExoPlayer** handles playback, adaptive formats, sessions, and audio/video decoding.
- **OkHttp** handles HTTP requests and downloads.
- **Rust (`rust/`)** optionally parses large WebVTT subtitle tracks through JNI. Kotlin remains the fallback.

The Rust path is deliberately limited to a CPU-bound text-parsing unit and is enabled only for tracks
above 16 KiB to avoid JNI overhead on short captions. Video playback and network transport are not
moved to Rust because those paths already use platform/native libraries. The parser has not yet been
benchmarked on physical devices, so no speedup is claimed.

## Build

```bash
./gradlew :app:assembleDebug
```

To include the Rust accelerator in the APK, install Rust stable, Android NDK, and `cargo-ndk`, then run:

```bash
rustup target add aarch64-linux-android armv7-linux-androideabi x86_64-linux-android
cargo install cargo-ndk
./scripts/build-rust-android.sh
./gradlew :app:assembleRelease
```

Without the native `.so` files, the app still runs using the Kotlin subtitle parser. The release variant is debug-signed for testing only. Its signing identity is not stable across
clean CI runners; configure a private release keystore before publishing or distributing updates. To configure in-app updates, set `RUSTUBE_RELEASES_API` to your own GitHub latest-release
API endpoint when building. The updater is intentionally not pointed at the upstream YTXTube repo.

## Credits and license

The source base is the YTXTube project. Preserve the included GPL-3.0 license and the upstream
attribution when redistributing this fork. This app is independent and is not affiliated with Google
or YouTube. Users are responsible for complying with applicable platform terms and copyright law.
