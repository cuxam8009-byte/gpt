# Notice

Rustube is derived from **YTXTube** (https://github.com/Koustubh12345/YTXTube), which is licensed under the
GNU General Public License v3.0. Rustube is distributed under the same license; the full text is in `LICENSE`.

## Modifications (2026-11-22)

- Package, application id, app name, icon and in-app branding replaced.
- Liquid Glass shaders and backdrop capture layers removed; translucent Apple-style surfaces and palette added.
- Start-up: the PO-token WebView warm-up moved out of `Application.onCreate`.
- Built-in measurement screen (frame timings, start-up steps, network vs. processing time, JSON benchmark).
- Upstream update feed, author links and donation/website material removed.


## Signal Atelier UI update (2026-11-22)

- Added the Signal Atelier design palette as Rustube's new default appearance.
- Added shared Compose controls and spacing/shape tokens for consistent screens.
- Refined the Home feed cards, navigation, filters, account/search actions, Music headings, Shorts controls, channel tabs, download sections, player action pills and Settings cards.
- Updated the in-app brand mark and Android launcher artwork.
- Existing playback, extraction, account, search, library, comments and download logic remains in the original feature modules.
