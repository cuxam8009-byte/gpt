# Rustube

Ứng dụng xem video cho Android (Kotlin + Jetpack Compose), sử dụng hệ nhận diện Signal Atelier của Rustube:
nền than chì, màu nhấn lime, các bề mặt phân lớp và component bo góc có phân cấp rõ ràng.
Hiệu ứng blur/shader Liquid Glass không được dùng trên thanh điều hướng hoặc các điều khiển mới; ưu tiên hiệu năng trên điện thoại phổ thông.

## Giao diện Signal Atelier

Design tokens và các component dùng chung được đặt trong `app/src/main/java/com/rustube/app/SignalDesign.kt`.
Theme Signal Atelier là theme mặc định cho cài đặt mới; các theme Apple và YouTube cũ vẫn có thể chọn lại trong Settings.
Các màn hình hiện có tiếp tục dùng chung luồng dữ liệu, điều hướng, tài khoản, tải xuống và phát media gốc.

## Bản đo hiệu năng

Mở app, chạm vào ô **FPS** nổi ở góc dưới bên phải (hoặc Cài đặt, mục Appearance & Theme, rồi Bản đo hiệu năng).
Màn hình này cho xem và sao chép: FPS và khung giật (UI / render / GPU), thời gian từng bước khởi động,
thời gian mạng và thời gian xử lý của từng tác vụ, bộ nhớ, và tốc độ parse JSON trên máy.

## Build

Chạy workflow **Build & Release** trên GitHub Actions (hoặc `./gradlew :app:assembleRelease`). Có kèm workflow **Build Rustube (from zip)** để build khi đưa ZIP dự án vào repo. Cần JDK 21 và Android SDK phù hợp với `compileSdk` của project.

Project đã được đóng gói mà không kèm `app/rustube.keystore`. Để ký bản release bằng khóa hiện có, giữ khóa riêng tư ở đúng đường dẫn `app/rustube.keystore` và cấu hình GitHub Actions secrets `KEYSTORE_PASSWORD` và `KEY_PASSWORD` (cùng `KEY_ALIAS` nếu alias khác `rustube`). Nếu không có keystore, Gradle dùng debug signing để tạo APK thử nghiệm; APK đó không thay thế được bản cài đặt đã ký bằng khóa phát hành trước đây.

## Giấy phép

GPL-3.0, xem `LICENSE`. Nguồn gốc và các thay đổi được ghi trong `NOTICE.md`.
