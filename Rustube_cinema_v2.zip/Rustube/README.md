# Rustube

Ứng dụng xem video cho Android (Kotlin + Jetpack Compose), giao diện kiểu Apple: trắng/đen, bề mặt trong suốt,
không dùng shader Liquid Glass. Đang được tối ưu dần để mượt hơn, kèm sẵn bộ đo hiệu năng.

## Bản đo hiệu năng

Mở app, chạm vào ô **FPS** nổi ở góc dưới bên phải (hoặc Cài đặt, mục Appearance & Theme, rồi Bản đo hiệu năng).
Màn hình này cho xem và sao chép: FPS và khung giật (UI / render / GPU), thời gian từng bước khởi động,
thời gian mạng và thời gian xử lý của từng tác vụ, bộ nhớ, và tốc độ parse JSON trên máy.

## Build

Chạy workflow **Build & Release** trên GitHub Actions (hoặc `./gradlew :app:assembleRelease`). Cần JDK 21.

## Giấy phép

GPL-3.0, xem `LICENSE`. Nguồn gốc và các thay đổi được ghi trong `NOTICE.md`.
