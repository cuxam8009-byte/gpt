# Rustube — ngôn ngữ thiết kế "Cinema"

Cùng ngôn ngữ với trang web Rustube Cinema Edition.

| Thành phần | Giá trị |
|---|---|
| Nền | `#050505` (đen sâu), panel `#111113`, `#18181B` |
| Viền | `#29292D` hairline 1dp |
| Hành động | Trắng `#F5F5F5` chữ đen (nút, chip, tab đang chọn) |
| Nhấn | Lime `#D6FF63` (`colorScheme.accent`), tím `#A995FF` (secondary) |
| Chữ | Sans đậm, tracking rất chặt cho tiêu đề; `MonoKicker` (monospace, in hoa) cho metadata |

Chữ ký riêng của app:
- **Dòng dateline mono** trên lời chào (`RUSTUBE / THỨ NĂM · 26 THG 11`) và dấu chấm lime kết thúc tiêu đề.
- **Thanh tua (`ScrubRule`)**: chấm lime như playhead, đường kẻ chuyển sắc, 8 thanh EQ lime.
- **Thẻ nổi bật kiểu điện ảnh (`FeaturedPager`)**: tối đa 3 thẻ vuốt ngang, vignette, khung viền trong, đếm `01 ━ 03`, nút Phát trắng với đĩa lime.
- **Tiêu đề mục** chạy thành đường kẻ mảnh, kèm số lượng (`08`).
- **Banner đăng nhập** là panel graphite có ánh lime góc phải trên, giống thẻ note của web.
- Chế độ sáng giữ nền giấy, lime được thay bằng olive đậm `#4E6B00` để vẫn đọc được.

## Điều hướng và "Kho"

Thanh dock còn 4 mục: **Trang chủ · Music · Shorts · Kho**. Kho gộp mọi thứ của riêng người dùng:

- Thẻ tài khoản (đăng nhập / quản lý), dải **Xem tiếp** lấy từ lịch sử.
- **Lịch sử xem**: lưu ngay trên máy, không cần đăng nhập (`WatchHistory`, tối đa 400 video). Nhóm theo ngày, lọc Video/Nhạc, xoá từng mục, xoá hết, tạm dừng lưu. Khi đã đăng nhập, lịch sử tài khoản YouTube hiện ở cuối.
- **Đã lưu**: video đánh dấu trên máy (`SavedVideos`, giữ lâu một video → "Lưu") và các danh sách phát.
- **Tải xuống**, **Kênh đăng ký**, và ô trắng **Cài đặt ứng dụng**.

## Âm thanh

Không còn mục "Audio track". Video có track tiếng Việt (lồng tiếng hoặc bản gốc) sẽ phát tiếng Việt; không có thì phát bản gốc. Phụ đề mặc định cũng là tiếng Việt.
