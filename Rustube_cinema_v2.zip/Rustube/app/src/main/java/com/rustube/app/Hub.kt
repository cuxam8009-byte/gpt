package com.rustube.app

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Bookmark
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteSweep
import androidx.compose.material.icons.rounded.Download
import androidx.compose.material.icons.rounded.History
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.PlayCircle
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.Subscriptions
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Calendar

/** The pages that live inside the Hub tab. */
enum class HubPage { Root, History, Saved, Downloads }

/**
 * The last tab of the dock: everything that belongs to the person rather than to the feed. Account,
 * watch history, saved videos, downloads, subscriptions and app settings in one place.
 */
@Composable
fun HubHost(
    page: HubPage,
    onPage: (HubPage) -> Unit,
    lib: LibraryData,
    contentPadding: PaddingValues,
    onOpen: (VideoItem) -> Unit,
    onOpenMusic: (VideoItem) -> Unit,
    onOpenPlaylist: (PlaylistRef) -> Unit,
    onOpenSubscriptions: () -> Unit,
    onOpenSettings: () -> Unit,
    onSignIn: () -> Unit,
    onSearch: () -> Unit,
    onBrowse: () -> Unit,
    onBrowseMusic: () -> Unit,
    scrollToTop: Int,
) {
    when (page) {
        HubPage.Root -> HubScreen(
            lib, contentPadding, onPage, onOpen, onOpenSubscriptions, onOpenSettings, onSignIn, onSearch, scrollToTop,
        )
        HubPage.History -> HistoryScreen(lib, contentPadding, onBack = { onPage(HubPage.Root) }, onOpen = onOpen)
        HubPage.Saved -> SavedScreen(lib, contentPadding, onBack = { onPage(HubPage.Root) }, onOpen = onOpen, onOpenPlaylist = onOpenPlaylist)
        HubPage.Downloads -> DownloadsScreen(
            contentPadding,
            onOpen = onOpen,
            onOpenMusic = onOpenMusic,
            onBrowse = onBrowse,
            onBrowseMusic = onBrowseMusic,
            onSearch = onSearch,
            onAccount = onOpenSettings,
            scrollToTop = scrollToTop,
        )
    }
}

@Composable
private fun HubScreen(
    lib: LibraryData,
    contentPadding: PaddingValues,
    onPage: (HubPage) -> Unit,
    onOpen: (VideoItem) -> Unit,
    onOpenSubscriptions: () -> Unit,
    onOpenSettings: () -> Unit,
    onSignIn: () -> Unit,
    onSearch: () -> Unit,
    scrollToTop: Int,
) {
    val signedIn = Account.signedIn
    LaunchedEffect(signedIn) {
        if (signedIn) {
            lib.history.ensureLoaded()
            if (lib.playlists.isEmpty()) lib.loadPlaylists()
            if (lib.channels.isEmpty()) lib.loadChannels()
        }
    }
    val local = WatchHistory.entries
    val resume = remember(local.size, ResumeStore.positions.size) {
        local.map { it.item }.filter { ResumeStore.progress(it.id) != null }.take(10)
    }
    val downloads = Downloads.tasks.size
    val subs = lib.channels.size

    CollapsingHeaderLayout(
        resetKey = scrollToTop,
        header = { ScreenHeader(title = rtText("Kho", "Hub")) { HeaderActions(onSearch, onOpenSettings) } },
    ) { top ->
        LazyColumn(state = rememberScrollToTop(scrollToTop), contentPadding = contentPadding.withTop(top)) {
            item(key = "account") { AccountPanel(onOpenSettings, onSignIn) }

            if (resume.isNotEmpty()) {
                item(key = "resumeTitle") { SectionTitle(rtText("Xem tiếp", "Continue watching"), count = resume.size) }
                item(key = "resume") { VideoShelf(resume, onOpen) }
            }

            item(key = "tilesTitle") { SectionTitle(rtText("Của bạn", "Yours")) }
            item(key = "tiles1") {
                TileRow(
                    HubTileData(
                        "01", Icons.Rounded.History, rtText("Lịch sử", "History"),
                        rtText("${local.size} video đã xem", "${local.size} watched"),
                    ) { onPage(HubPage.History) },
                    HubTileData(
                        "02", Icons.Rounded.Bookmark, rtText("Đã lưu", "Saved"),
                        rtText("${SavedVideos.entries.size} video trên máy", "${SavedVideos.entries.size} on this device"),
                    ) { onPage(HubPage.Saved) },
                )
            }
            item(key = "tiles2") {
                TileRow(
                    HubTileData(
                        "03", Icons.Rounded.Download, rtText("Tải xuống", "Downloads"),
                        if (Downloads.busy) rtText("Đang tải…", "Downloading…") else rtText("$downloads tệp", "$downloads files"),
                    ) { onPage(HubPage.Downloads) },
                    HubTileData(
                        "04", Icons.Rounded.Subscriptions, rtText("Kênh đăng ký", "Subscriptions"),
                        if (signedIn) rtText("$subs kênh", "$subs channels") else rtText("Đăng nhập để xem", "Sign in to see"),
                    ) { if (signedIn) onOpenSubscriptions() else onSignIn() },
                )
            }
            item(key = "settings") { SettingsTile(onOpenSettings) }
        }
    }
}

/** Account card: a graphite panel with the lime glow of the website's note tile. */
@Composable
private fun AccountPanel(onOpenSettings: () -> Unit, onSignIn: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val profile = Account.profile
    val glow = c.accent
    val shape = RoundedCornerShape(26.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 8.dp)
            .clip(shape)
            .background(c.surfaceContainerLow)
            .drawBehind {
                drawRect(
                    Brush.radialGradient(
                        colors = listOf(glow.copy(alpha = 0.18f), Color.Transparent),
                        center = Offset(size.width, 0f),
                        radius = size.width * 0.8f,
                    ),
                )
            }
            .border(1.dp, c.outlineVariant, shape)
            .pressable(pressedScale = 0.98f) { if (profile == null) onSignIn() else onOpenSettings() }
            .padding(18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        if (profile != null) {
            ChannelAvatar(profile.avatar, profile.name, size = 56)
        } else {
            Box(
                Modifier.size(56.dp).clip(CircleShape).background(c.surfaceContainerHigh),
                contentAlignment = Alignment.Center,
            ) {
                Icon(Icons.Rounded.Settings, null, tint = c.onSurfaceVariant, modifier = Modifier.size(26.dp))
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            MonoKicker(
                if (profile != null) rtText("Tài khoản", "Account") else rtText("Khách", "Guest"),
                color = glow,
                size = 9.sp,
            )
            Spacer(Modifier.height(4.dp))
            Text(
                profile?.name ?: rtText("Chưa đăng nhập", "Not signed in"),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 20.sp,
                lineHeight = 24.sp,
                letterSpacing = (-0.7).sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                profile?.handle ?: rtText("Đăng nhập để đồng bộ đăng ký và danh sách phát", "Sign in to sync subscriptions and playlists"),
                color = c.onSurfaceVariant,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis,
            )
        }
        if (profile == null) {
            Spacer(Modifier.width(10.dp))
            PillButton(rtText("Đăng nhập", "Sign in"), onSignIn)
        }
    }
}

private class HubTileData(val index: String, val icon: ImageVector, val title: String, val subtitle: String, val onClick: () -> Unit)

@Composable
private fun TileRow(left: HubTileData, right: HubTileData) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp),
    ) {
        HubTile(left, Modifier.weight(1f))
        HubTile(right, Modifier.weight(1f))
    }
}

/** A tile in the style of the website's capability cards: mono index, faint glyph, heavy title. */
@Composable
private fun HubTile(data: HubTileData, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(24.dp)
    Box(
        modifier = modifier
            .height(150.dp)
            .clip(shape)
            .background(c.surfaceContainer)
            .border(1.dp, c.outlineVariant, shape)
            .pressable(pressedScale = 0.97f, onClick = data.onClick),
    ) {
        Icon(
            data.icon, null,
            tint = c.onSurface.copy(alpha = 0.10f),
            modifier = Modifier.align(Alignment.TopEnd).padding(top = 10.dp, end = 10.dp).size(64.dp),
        )
        Column(Modifier.fillMaxWidth().align(Alignment.BottomStart).padding(18.dp)) {
            MonoKicker(data.index, color = c.accent, size = 10.sp)
            Spacer(Modifier.height(18.dp))
            Text(
                data.title,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 19.sp,
                lineHeight = 22.sp,
                letterSpacing = (-0.7).sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(Modifier.height(3.dp))
            Text(
                data.subtitle,
                color = c.onSurfaceVariant,
                fontSize = 12.sp,
                lineHeight = 16.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
    }
}

/** The one white tile, like the website's wide control card: settings stand out from the dark tiles. */
@Composable
private fun SettingsTile(onClick: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 5.dp)
            .clip(shape)
            .background(Color(0xFFE9E9E9))
            .pressable(pressedScale = 0.98f, onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 20.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Settings, null, tint = Color(0xFF090909), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                rtText("Cài đặt ứng dụng", "App settings"),
                color = Color(0xFF090909),
                fontWeight = FontWeight.ExtraBold,
                fontSize = 18.sp,
                letterSpacing = (-0.6).sp,
            )
            Text(
                rtText("Giao diện, phát lại, tải xuống, tài khoản", "Look, playback, downloads, account"),
                color = Color(0xFF626269),
                fontSize = 12.sp,
                lineHeight = 16.sp,
                maxLines = 2,
            )
        }
        EqBars(color = Color(0xFF111111))
    }
}

/* ------------------------------------------------------------------------------------------ */

private fun dayBucket(at: Long): Int {
    val now = Calendar.getInstance()
    val then = Calendar.getInstance().apply { timeInMillis = at }
    fun Calendar.dayNumber() = get(Calendar.YEAR) * 366 + get(Calendar.DAY_OF_YEAR)
    return when (now.dayNumber() - then.dayNumber()) {
        0 -> 0
        1 -> 1
        in 2..7 -> 2
        else -> 3
    }
}

private fun bucketLabel(bucket: Int): String = when (bucket) {
    0 -> rtText("Hôm nay", "Today")
    1 -> rtText("Hôm qua", "Yesterday")
    2 -> rtText("Tuần này", "This week")
    else -> rtText("Trước đó", "Earlier")
}

@Composable
private fun HubChip(label: String, selected: Boolean, onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .height(38.dp)
            .clip(CircleShape)
            .background(if (selected) c.primary else c.surfaceContainer)
            .border(1.dp, if (selected) Color.Transparent else c.outlineVariant, CircleShape)
            .pressable(pressedScale = 0.95f, onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            color = if (selected) c.onPrimary else c.onSurfaceVariant,
            fontWeight = if (selected) FontWeight.ExtraBold else FontWeight.SemiBold,
            fontSize = 13.sp,
            maxLines = 1,
        )
    }
}

@Composable
private fun RemoveButton(onClick: () -> Unit) {
    val c = MaterialTheme.colorScheme
    Box(
        Modifier.size(40.dp).clip(CircleShape).pressable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Rounded.Close, rtText("Xoá", "Remove"), tint = c.onSurfaceVariant, modifier = Modifier.size(18.dp))
    }
}

/** Header of a Hub sub-page: back button, mono kicker, heavy title, optional actions. */
@Composable
private fun HubPageHeader(title: String, onBack: () -> Unit, actions: @Composable () -> Unit = {}) {
    BackScreenHeader(onBack) {
        Column(Modifier.weight(1f)) {
            MonoKicker("RUSTUBE / ${rtText("Kho", "Hub")}", color = MaterialTheme.colorScheme.accent, size = 9.sp)
            Text(
                title,
                fontWeight = FontWeight.ExtraBold,
                fontSize = 26.sp,
                lineHeight = 30.sp,
                letterSpacing = (-1.2).sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { actions() }
    }
}

@Composable
private fun HistoryScreen(
    lib: LibraryData,
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpen: (VideoItem) -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val signedIn = Account.signedIn
    LaunchedEffect(signedIn) { if (signedIn) lib.history.ensureLoaded() }
    var filter by remember { mutableStateOf(0) } // 0 all, 1 video, 2 music
    var confirmClear by remember { mutableStateOf(false) }

    fun keep(v: VideoItem): Boolean = when (filter) {
        1 -> !isMusicTrack(v)
        2 -> isMusicTrack(v)
        else -> true
    }

    val local = WatchHistory.entries.filter { keep(it.item) }
    val localIds = WatchHistory.entries.map { it.item.id }.toHashSet()
    val account = if (signedIn) lib.history.videos.filter { it.id !in localIds && keep(it) } else emptyList()
    val grouped = local.groupBy { dayBucket(it.at) }.toSortedMap()

    CollapsingHeaderLayout(
        resetKey = filter,
        header = {
            HubPageHeader(rtText("Lịch sử xem", "Watch history"), onBack) {
                CircleAction(
                    if (WatchHistory.paused) Icons.Rounded.PlayCircle else Icons.Rounded.PauseCircle,
                    if (WatchHistory.paused) rtText("Bật lại lưu lịch sử", "Resume history") else rtText("Tạm dừng lưu lịch sử", "Pause history"),
                ) { WatchHistory.setPaused(!WatchHistory.paused) }
                CircleAction(Icons.Rounded.DeleteSweep, rtText("Xoá lịch sử", "Clear history")) { confirmClear = true }
            }
        },
    ) { top ->
        LazyColumn(contentPadding = contentPadding.withTop(top)) {
            item(key = "filters") {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                ) {
                    HubChip(rtText("Tất cả", "All"), filter == 0) { filter = 0 }
                    HubChip("Video", filter == 1) { filter = 1 }
                    HubChip(rtText("Nhạc", "Music"), filter == 2) { filter = 2 }
                }
            }
            if (WatchHistory.paused) {
                item(key = "paused") {
                    Text(
                        rtText(
                            "Đang tạm dừng: video mới xem sẽ không được lưu.",
                            "Paused: videos you watch now are not saved.",
                        ),
                        color = c.accent,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 6.dp),
                    )
                }
            }
            if (local.isEmpty() && account.isEmpty()) {
                item(key = "empty") {
                    EmptyState(
                        icon = Icons.Rounded.History,
                        title = rtText("Chưa có lịch sử", "No history yet"),
                        body = rtText(
                            "Video bạn xem sẽ được lưu ở đây, ngay trên máy, không cần đăng nhập.",
                            "Videos you watch are saved here, on this device, no sign-in needed.",
                        ),
                    )
                }
            }
            grouped.forEach { (bucket, list) ->
                item(key = "bucket-$bucket") {
                    Row(Modifier.padding(start = 20.dp, end = 20.dp, top = 20.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        MonoKicker(bucketLabel(bucket), color = c.accent)
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f).height(1.dp).background(c.outlineVariant))
                        Spacer(Modifier.width(10.dp))
                        MonoKicker(list.size.toString().padStart(2, '0'))
                    }
                }
                items(list, key = { "l-" + it.item.id }) { entry ->
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        VideoRow(entry.item, onClick = { onOpen(entry.item) }) {
                            RemoveButton { WatchHistory.remove(entry.item.id) }
                        }
                    }
                }
            }
            if (account.isNotEmpty()) {
                item(key = "accountTitle") {
                    Row(Modifier.padding(start = 20.dp, end = 20.dp, top = 24.dp, bottom = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        MonoKicker(rtText("Từ tài khoản YouTube", "From your YouTube account"), color = c.accent)
                        Spacer(Modifier.width(10.dp))
                        Box(Modifier.weight(1f).height(1.dp).background(c.outlineVariant))
                    }
                }
                items(account, key = { "a-" + it.id }) { video ->
                    Box(Modifier.padding(horizontal = 16.dp)) { VideoRow(video, onClick = { onOpen(video) }) }
                }
            }
        }
    }

    if (confirmClear) {
        AlertDialog(
            onDismissRequest = { confirmClear = false },
            title = { Text(rtText("Xoá lịch sử xem?", "Clear watch history?"), fontWeight = FontWeight.Bold) },
            text = { Text(rtText("Toàn bộ lịch sử lưu trên máy sẽ bị xoá. Không thể hoàn tác.", "Everything saved on this device will be deleted. This cannot be undone.")) },
            confirmButton = {
                TextButton(onClick = { WatchHistory.clear(); confirmClear = false }) { Text(rtText("Xoá", "Clear")) }
            },
            dismissButton = {
                TextButton(onClick = { confirmClear = false }) { Text(rtText("Huỷ", "Cancel")) }
            },
        )
    }
}

@Composable
private fun SavedScreen(
    lib: LibraryData,
    contentPadding: PaddingValues,
    onBack: () -> Unit,
    onOpen: (VideoItem) -> Unit,
    onOpenPlaylist: (PlaylistRef) -> Unit,
) {
    val c = MaterialTheme.colorScheme
    val signedIn = Account.signedIn
    LaunchedEffect(signedIn) { if (signedIn && lib.playlists.isEmpty()) lib.loadPlaylists() }
    val saved = SavedVideos.entries
    val pinned = buildList {
        if (signedIn) add(PlaylistRef("WL", "Watch later", null, null))
        add(PlaylistRef("MDL", "Rustube Music Downloads", null, null))
        if (signedIn) add(PlaylistRef("LL", "Liked videos", null, null))
    }

    CollapsingHeaderLayout(
        header = { HubPageHeader(rtText("Đã lưu", "Saved"), onBack) },
    ) { top ->
        LazyColumn(contentPadding = contentPadding.withTop(top)) {
            item(key = "savedTitle") { SectionTitle(rtText("Trên máy", "On this device"), count = saved.size) }
            if (saved.isEmpty()) {
                item(key = "savedEmpty") {
                    Text(
                        rtText(
                            "Giữ lâu một video rồi chọn “Lưu” để thêm vào đây.",
                            "Press and hold a video, then choose “Save” to add it here.",
                        ),
                        color = c.onSurfaceVariant,
                        fontSize = 14.sp,
                        lineHeight = 20.sp,
                        modifier = Modifier.padding(horizontal = 20.dp, vertical = 4.dp),
                    )
                }
            } else {
                items(saved, key = { "s-" + it.item.id }) { entry ->
                    Box(Modifier.padding(horizontal = 16.dp)) {
                        VideoRow(entry.item, onClick = { onOpen(entry.item) }) {
                            RemoveButton { SavedVideos.remove(entry.item.id) }
                        }
                    }
                }
            }
            item(key = "playlistsTitle") { SectionTitle(rtText("Danh sách phát", "Playlists")) }
            items((pinned + lib.playlists).chunked(2), key = { row -> "p-" + row.joinToString { it.id } }) { row ->
                Row(Modifier.padding(horizontal = 16.dp, vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    row.forEach { pl -> PlaylistTile(pl, Modifier.weight(1f)) { onOpenPlaylist(pl) } }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}
