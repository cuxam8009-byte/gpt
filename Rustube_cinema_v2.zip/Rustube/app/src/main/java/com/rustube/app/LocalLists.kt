package com.rustube.app

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject

/** One video in a local list, with the moment it was added. */
data class LocalEntry(val item: VideoItem, val at: Long)

/**
 * A short list of videos kept on the device, newest first, stored as JSON in SharedPreferences.
 * It needs no account: this is what makes history and "saved" work for everyone.
 */
class LocalVideoList(private val prefsName: String, private val max: Int) {
    private var prefs: SharedPreferences? = null
    val entries = mutableStateListOf<LocalEntry>()

    fun init(context: Context) {
        val p = context.getSharedPreferences(prefsName, Context.MODE_PRIVATE).also { prefs = it }
        val raw = p.getString("items", null) ?: return
        val loaded = runCatching {
            val arr = JSONArray(raw)
            (0 until arr.length()).mapNotNull { i -> arr.optJSONObject(i)?.toEntry() }
        }.getOrDefault(emptyList())
        entries.clear()
        entries.addAll(loaded)
    }

    fun contains(id: String): Boolean = entries.any { it.item.id == id }

    /** Adds the video at the top; a video already in the list moves to the top instead of repeating. */
    fun add(item: VideoItem, at: Long = System.currentTimeMillis()) {
        if (item.id.isBlank() || item.localUri != null) return
        entries.removeAll { it.item.id == item.id }
        entries.add(0, LocalEntry(item, at))
        while (entries.size > max) entries.removeAt(entries.lastIndex)
        persist()
    }

    fun remove(id: String) {
        if (entries.removeAll { it.item.id == id }) persist()
    }

    fun clear() {
        entries.clear()
        persist()
    }

    private fun persist() {
        val arr = JSONArray()
        entries.forEach { arr.put(it.toJson()) }
        prefs?.edit()?.putString("items", arr.toString())?.apply()
    }
}

private fun JSONObject.str(key: String): String? = if (has(key) && !isNull(key)) getString(key).takeIf { it.isNotEmpty() } else null

private fun LocalEntry.toJson(): JSONObject = JSONObject()
    .put("id", item.id)
    .put("title", item.title)
    .put("channel", item.channel)
    .put("channelUrl", item.channelUrl ?: JSONObject.NULL)
    .put("thumbnail", item.thumbnail ?: JSONObject.NULL)
    .put("avatar", item.avatar ?: JSONObject.NULL)
    .put("durationSec", item.durationSec)
    .put("views", item.views)
    .put("uploaded", item.uploaded ?: JSONObject.NULL)
    .put("isLive", item.isLive)
    .put("at", at)

private fun JSONObject.toEntry(): LocalEntry? {
    val id = str("id") ?: return null
    return LocalEntry(
        item = VideoItem(
            id = id,
            title = str("title").orEmpty(),
            channel = str("channel").orEmpty(),
            channelUrl = str("channelUrl"),
            thumbnail = str("thumbnail"),
            avatar = str("avatar"),
            durationSec = optLong("durationSec", 0L),
            views = optLong("views", -1L),
            uploaded = str("uploaded"),
            isLive = optBoolean("isLive", false),
        ),
        at = optLong("at", 0L),
    )
}

/**
 * Watch history saved on the device. Every video that starts playing is recorded, so history works
 * without signing in; when an account is signed in its own history is shown after this list.
 */
object WatchHistory {
    private val list = LocalVideoList("watch_history", 400)
    private var meta: SharedPreferences? = null

    /** While paused, nothing new is recorded. What is already saved stays until it is deleted. */
    var paused by mutableStateOf(false)
        private set

    val entries: List<LocalEntry> get() = list.entries

    fun init(context: Context) {
        list.init(context)
        meta = context.getSharedPreferences("watch_history_meta", Context.MODE_PRIVATE)
        paused = meta?.getBoolean("paused", false) == true
    }

    fun record(item: VideoItem) {
        if (!paused) list.add(item)
    }

    fun setPaused(value: Boolean) {
        paused = value
        meta?.edit()?.putBoolean("paused", value)?.apply()
    }

    fun remove(id: String) = list.remove(id)
    fun clear() = list.clear()
}

/** Videos the person bookmarked on the device ("Đã lưu"). Works without an account. */
object SavedVideos {
    private val list = LocalVideoList("saved_videos", 500)

    val entries: List<LocalEntry> get() = list.entries

    fun init(context: Context) = list.init(context)

    fun contains(id: String): Boolean = list.contains(id)

    fun toggle(item: VideoItem): Boolean {
        return if (list.contains(item.id)) {
            list.remove(item.id)
            false
        } else {
            list.add(item)
            true
        }
    }

    fun remove(id: String) = list.remove(id)
}
