package com.rustube.app

import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.requiredSize
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.Typography
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material3.ColorScheme
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.style.TextOverflow

/*
 * Rustube design language: "Cinema" (the same language as the Rustube website).
 *
 *  - Near-black screens, graphite panels, hairline borders. White is the action colour: the selected state
 *    is always a white pill with dark text. One lime accent (#D6FF63) marks kickers, the playhead and "now".
 *  - Monospace upper-case kickers with wide tracking ("RUSTUBE / THỨ NĂM · 26 THG 11", "01 ━ 03") for
 *    anything that is metadata; heavy, tightly tracked sans for headlines.
 *  - The hero is a cinema frame: vignette, inset hairline frame, a counter, one white play pill.
 *  - Flat and cheap to draw: solid fills, gradients and hairlines, no blur, no shadows, no offscreen layers.
 */

/** The lime of the Rustube website (#D6FF63): kickers, markers, the "now" of the interface. */
val CinemaLime = Color(0xFFD6FF63)

/** The accent colour of the current scheme: lime in the dark Cinema look, deep olive in light mode. */
val ColorScheme.accent: Color get() = tertiary

/**
 * Small upper-case monospace label with wide tracking, the "SCREEN / 01 — HOME" voice of the website.
 * Used for kickers, counters and metadata so the app reads like the site.
 */
@Composable
fun MonoKicker(
    text: String,
    modifier: Modifier = Modifier,
    color: Color = Color.Unspecified,
    size: androidx.compose.ui.unit.TextUnit = 10.sp,
) {
    Text(
        text = text.uppercase(),
        modifier = modifier,
        color = if (color == Color.Unspecified) MaterialTheme.colorScheme.onSurfaceVariant else color,
        fontFamily = FontFamily.Monospace,
        fontSize = size,
        lineHeight = 14.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 1.4.sp,
        maxLines = 1,
        overflow = TextOverflow.Ellipsis,
    )
}

private val EqHeights = listOf(5, 10, 14, 18, 12, 10, 14, 5)

/** The eight lime bars from the website's note card. Static on purpose: it costs nothing to draw. */
@Composable
fun EqBars(modifier: Modifier = Modifier, color: Color = Color.Unspecified) {
    val tint = if (color == Color.Unspecified) MaterialTheme.colorScheme.accent else color
    Row(
        modifier = modifier.height(18.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(3.dp),
    ) {
        EqHeights.forEach { h ->
            Box(Modifier.width(3.dp).height(h.dp).clip(RoundedCornerShape(2.dp)).background(tint.copy(alpha = 0.85f)))
        }
    }
}

private val baseTypography = Typography()

val RustubeTypography: Typography = baseTypography.copy(
    headlineLarge = baseTypography.headlineLarge.copy(fontWeight = FontWeight.ExtraBold, fontSize = 36.sp, lineHeight = 40.sp, letterSpacing = (-1.6).sp),
    headlineMedium = baseTypography.headlineMedium.copy(fontWeight = FontWeight.ExtraBold, fontSize = 29.sp, lineHeight = 34.sp, letterSpacing = (-1.2).sp),
    headlineSmall = baseTypography.headlineSmall.copy(fontWeight = FontWeight.Bold, fontSize = 24.sp, lineHeight = 30.sp, letterSpacing = (-0.4).sp),
    titleLarge = baseTypography.titleLarge.copy(fontWeight = FontWeight.Bold, fontSize = 22.sp, lineHeight = 28.sp, letterSpacing = (-0.7).sp),
    titleMedium = baseTypography.titleMedium.copy(fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 22.sp, letterSpacing = (-0.2).sp),
    titleSmall = baseTypography.titleSmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 15.sp, lineHeight = 20.sp, letterSpacing = 0.sp),
    bodyLarge = baseTypography.bodyLarge.copy(fontSize = 16.sp, lineHeight = 22.sp, letterSpacing = 0.sp),
    bodyMedium = baseTypography.bodyMedium.copy(fontSize = 14.sp, lineHeight = 20.sp, letterSpacing = 0.sp),
    bodySmall = baseTypography.bodySmall.copy(fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.sp),
    labelLarge = baseTypography.labelLarge.copy(fontWeight = FontWeight.SemiBold, fontSize = 14.sp, lineHeight = 18.sp, letterSpacing = 0.sp),
    labelMedium = baseTypography.labelMedium.copy(fontWeight = FontWeight.Medium, fontSize = 12.sp, lineHeight = 16.sp, letterSpacing = 0.2.sp),
    labelSmall = baseTypography.labelSmall.copy(fontWeight = FontWeight.Medium, fontSize = 11.sp, lineHeight = 14.sp, letterSpacing = 0.3.sp),
)

/** The app mark drawn in the theme's own colours: an ink square holding the paper gear-and-play glyph. */
@Composable
fun RustubeBadge(size: Dp = 32.dp) {
    val c = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .size(size)
            .clip(RoundedCornerShape(size * 0.28f))
            .background(c.onSurface),
        contentAlignment = Alignment.Center,
    ) {
        Icon(
            painter = painterResource(R.drawable.ic_launcher_monochrome),
            contentDescription = null,
            tint = c.surface,
            modifier = Modifier.requiredSize(size * 1.25f),
        )
    }
}

/** The website wordmark: lowercase "rustube" in ink, closed by a lime full stop. */
@Composable
fun RustubeWordmark(modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        RustubeBadge(32.dp)
        Spacer(Modifier.width(10.dp))
        Text(
            text = buildAnnotatedString {
                withStyle(SpanStyle(color = c.onSurface)) { append("rus") }
                withStyle(SpanStyle(color = c.onSurface)) { append("tube") }
                withStyle(SpanStyle(color = c.accent)) { append(".") }
            },
            fontWeight = FontWeight.ExtraBold,
            fontSize = 30.sp,
            letterSpacing = (-1.4).sp,
            maxLines = 1,
        )
    }
}

/** A full-width search field that opens search when tapped. */
@Composable
fun HomeSearchPill(onClick: () -> Unit, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 4.dp)
            .pressable(pressedScale = 0.985f, onClick = onClick)
            .height(46.dp)
            .clip(CircleShape)
            .background(c.surfaceContainer)
            .border(1.dp, c.outlineVariant, CircleShape)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(Icons.Rounded.Search, contentDescription = null, tint = c.onSurfaceVariant, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Text(
            text = I18n.t("search_hint", "Search videos"),
            color = c.onSurfaceVariant,
            fontSize = 16.sp,
            maxLines = 1,
        )
    }
}

/**
 * Rustube's floating dock. Every tab is an icon; the selected one grows into an ink pill that also shows
 * its name. Same 64 dp height as before, so the screens above it keep their spacing.
 */
@Composable
fun RustubeDock(
    selected: Tab,
    onSelect: (Tab) -> Unit,
    onDark: Boolean,
    modifier: Modifier = Modifier,
) {
    val c = MaterialTheme.colorScheme
    val container = if (onDark) Color(0xFF0B0B0C).copy(alpha = 0.94f) else c.surfaceContainerLow.copy(alpha = 0.95f)
    val edge = if (onDark) Color(0xFF29292D) else c.outlineVariant
    val ink = if (onDark) Color(0xFFF5F5F5) else c.onSurface
    val paper = if (onDark) Color.Black else c.surface
    val idle = if (onDark) Color(0xFF929298) else c.onSurfaceVariant

    Row(
        modifier = modifier
            .height(64.dp)
            .clip(CircleShape)
            .background(container)
            .border(1.dp, edge, CircleShape)
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        Tab.entries.forEach { t ->
            val isSelected = t == selected
            val grow by animateFloatAsState(
                targetValue = if (isSelected) 2.4f else 1f,
                animationSpec = tween(240),
                label = "dockWeight",
            )
            val downloading = t == Tab.Hub && Downloads.busy
            Box(
                modifier = Modifier
                    .weight(grow)
                    .fillMaxHeight()
                    .clip(CircleShape)
                    .background(if (isSelected) ink else Color.Transparent)
                    .pressable(pressedScale = 0.92f) { onSelect(t) },
                contentAlignment = Alignment.Center,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(modifier = Modifier.size(26.dp), contentAlignment = Alignment.Center) {
                        if (downloading) {
                            CircularProgressIndicator(
                                progress = { Downloads.progress },
                                color = if (isSelected) paper else c.accent,
                                strokeWidth = 1.5.dp,
                                modifier = Modifier.size(26.dp),
                            )
                        }
                        Icon(
                            imageVector = if (isSelected) t.selectedIcon else t.icon,
                            contentDescription = t.label,
                            tint = if (isSelected) paper else idle,
                            modifier = Modifier.size(if (downloading) 16.dp else 22.dp),
                        )
                    }
                    if (isSelected) {
                        Spacer(Modifier.width(6.dp))
                        Text(
                            text = t.label,
                            color = paper,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold,
                            maxLines = 1,
                            softWrap = false,
                        )
                    }
                }
            }
        }
    }
}


/** Picks the Vietnamese text when the app language is Vietnamese, otherwise the English one. */
fun rtText(vi: String, en: String): String =
    if (LanguageSettings.effectiveLanguageCode().startsWith("vi")) vi else en

/** The same scheme with ink and paper swapped: used for surfaces that must stand out (the mini player). */
fun ColorScheme.inverted(): ColorScheme = copy(
    primary = surface,
    onPrimary = onSurface,
    primaryContainer = surface.copy(alpha = 0.18f),
    onPrimaryContainer = surface,
    background = onSurface,
    onBackground = surface,
    surface = onSurface,
    onSurface = surface,
    surfaceVariant = onSurface,
    onSurfaceVariant = surface.copy(alpha = 0.72f),
    surfaceContainerLowest = onSurface,
    surfaceContainerLow = onSurface,
    surfaceContainer = onSurface,
    surfaceContainerHigh = onSurface,
    surfaceContainerHighest = onSurface,
    outline = surface.copy(alpha = 0.40f),
    outlineVariant = surface.copy(alpha = 0.16f),
)

/** Rustube's loading mark: the gear turns slowly around a play button that stays still. */
@Composable
fun RustubeLoader(size: Dp = 32.dp, modifier: Modifier = Modifier) {
    val c = MaterialTheme.colorScheme
    val transition = rememberInfiniteTransition(label = "rustubeLoader")
    val angle by transition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(animation = tween(2600, easing = LinearEasing)),
        label = "rustubeGear",
    )
    Box(modifier = modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(
            painter = painterResource(R.drawable.ic_rt_gear),
            contentDescription = null,
            tint = c.onSurface,
            modifier = Modifier
                .requiredSize(size * 2f)
                .graphicsLayer { rotationZ = angle },
        )
        Icon(
            painter = painterResource(R.drawable.ic_rt_play),
            contentDescription = null,
            tint = c.accent,
            modifier = Modifier.requiredSize(size * 2f),
        )
    }
}

/** The small play notch that opens every section title. */
@Composable
fun RustubeNotch(size: Dp = 14.dp, modifier: Modifier = Modifier) {
    Icon(
        imageVector = Icons.Rounded.PlayArrow,
        contentDescription = null,
        tint = MaterialTheme.colorScheme.accent,
        modifier = modifier.size(size),
    )
}

private fun greetingText(): String {
    val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
    return when (hour) {
        in 5..10 -> rtText("Chào buổi sáng", "Good morning")
        in 11..13 -> rtText("Chào buổi trưa", "Good afternoon")
        in 14..17 -> rtText("Chào buổi chiều", "Good afternoon")
        in 18..22 -> rtText("Chào buổi tối", "Good evening")
        else -> rtText("Khuya rồi", "Late night")
    }
}

/** "THỨ NĂM · 26 THÁNG 11": the small dateline that sits above the greeting, like a newspaper masthead. */
private fun datelineText(): String {
    val locale = java.util.Locale.forLanguageTag(LanguageSettings.effectiveLanguageCode())
    return runCatching {
        java.text.SimpleDateFormat("EEEE · d MMM", locale).format(java.util.Date()).uppercase(locale)
    }.getOrDefault("")
}

/**
 * Home header, laid out like a masthead: badge + dateline on top, the time-of-day greeting as the headline
 * (ending in a grey full stop, the way the wordmark ends in grey), the account button on the right.
 * The whole block sits below the status bar, so nothing slides under the clock and battery icons.
 */
@Composable
fun HomeHeader(onAccount: () -> Unit) {
    val c = MaterialTheme.colorScheme
    val greeting = androidx.compose.runtime.remember { greetingText() }
    val dateline = androidx.compose.runtime.remember { datelineText() }
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(start = 20.dp, end = 12.dp, top = 6.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RustubeBadge(18.dp)
                Spacer(Modifier.width(8.dp))
                MonoKicker(
                    text = if (dateline.isBlank()) "RUSTUBE / HOME" else "RUSTUBE / $dateline",
                    size = 10.sp,
                )
            }
            Spacer(Modifier.height(2.dp))
            Text(
                text = buildAnnotatedString {
                    withStyle(SpanStyle(color = c.onSurface)) { append(greeting) }
                    withStyle(SpanStyle(color = c.accent)) { append(".") }
                },
                fontSize = 34.sp,
                lineHeight = 38.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = (-1.8).sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        AccountAction(onAccount)
    }
}

/**
 * Rustube's signature rule: a hairline with an ink playhead at its start, like the timeline of a video.
 * It closes the header and is reused to end section titles.
 */
@Composable
fun ScrubRule(modifier: Modifier = Modifier, bars: Boolean = true) {
    val c = MaterialTheme.colorScheme
    Row(
        modifier = modifier
            .fillMaxWidth()
            .padding(start = 20.dp, end = 20.dp, top = 8.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(7.dp).clip(CircleShape).background(c.accent))
        Box(
            Modifier
                .weight(1f)
                .height(1.dp)
                .background(Brush.horizontalGradient(listOf(c.accent.copy(alpha = 0.55f), c.outlineVariant, Color.Transparent))),
        )
        if (bars) {
            Spacer(Modifier.width(12.dp))
            EqBars()
        }
    }
}

/** White play pill shown on the hero card. The whole card is the button, this only says what a tap does. */
@Composable
fun RustubePlayPill(modifier: Modifier = Modifier) {
    Row(
        modifier = modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(Color(0xFFF5F5F5))
            .padding(start = 6.dp, end = 18.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(Modifier.size(28.dp).clip(CircleShape).background(CinemaLime), contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.PlayArrow, contentDescription = null, tint = Color.Black, modifier = Modifier.size(19.dp))
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = rtText("Phát", "Play"),
            color = Color.Black,
            fontSize = 14.sp,
            fontWeight = FontWeight.ExtraBold,
            letterSpacing = (-0.2).sp,
            maxLines = 1,
        )
    }
}

/** Card used on horizontal shelves: 16:9 art, two lines of title, the channel. */
@Composable
fun ShelfCard(video: VideoItem, onClick: () -> Unit, modifier: Modifier = Modifier, width: Dp = 250.dp) {
    val c = MaterialTheme.colorScheme
    val menu = LocalVideoMenu.current
    Column(
        modifier = modifier
            .width(width)
            .prefetchOnPress(video.id)
            .pressable(pressedScale = 0.97f, onLongClick = { menu(video) }, onClick = onClick),
    ) {
        Box {
            Thumbnail(video.thumbnail, Modifier.fillMaxWidth().aspectRatio(16f / 9f), radius = 18, videoId = video.id)
            DurationPill(video.durationSec, Modifier.align(Alignment.BottomEnd).padding(8.dp), small = true, isLive = video.isLive)
            ResumeBar(
                video.id,
                Modifier
                    .align(Alignment.BottomStart)
                    .clip(RoundedCornerShape(bottomStart = 18.dp, bottomEnd = 18.dp)),
            )
        }
        Spacer(Modifier.height(8.dp))
        Text(
            text = video.title,
            fontSize = 15.sp,
            lineHeight = 20.sp,
            fontWeight = FontWeight.Bold,
            letterSpacing = (-0.4).sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
        )
        if (video.channel.isNotBlank()) {
            Spacer(Modifier.height(4.dp))
            MonoKicker(video.channel, size = 9.sp)
        }
    }
}

/** A horizontal rail of [ShelfCard]s. */
@Composable
fun VideoShelf(videos: List<VideoItem>, onOpen: (VideoItem) -> Unit, modifier: Modifier = Modifier) {
    LazyRow(
        modifier = modifier,
        contentPadding = PaddingValues(horizontal = 16.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        items(videos, key = { "shelf-" + it.id }, contentType = { "shelfCard" }) { video ->
            ShelfCard(video, onClick = { onOpen(video) })
        }
    }
}


/**
 * The top of the feed as a swipeable "now showing" reel: up to three hero cards, each with its counter
 * (01 ━ 03), like the scenes on the website. The pager keeps its page while the list scrolls.
 */
@Composable
fun FeaturedPager(videos: List<VideoItem>, onOpen: (VideoItem) -> Unit) {
    if (videos.isEmpty()) return
    val state = androidx.compose.foundation.pager.rememberPagerState(pageCount = { videos.size })
    androidx.compose.foundation.pager.HorizontalPager(state = state, key = { videos[it].id }) { page ->
        val v = videos[page]
        VideoCard(v, onClick = { onOpen(v) }, hero = true, heroIndex = page + 1, heroCount = videos.size)
    }
}
